## John Doe

### Arlington, GA 39813 ◆ 555 555 5555 ◆ example@example.com

## Professional Summary
Knowledgeable Customer Service Representative with problem-solving abilities capable of building
customer rapport. Effectively handles customer concerns with clear communication and patience. Able to
take on various tasks at a customer-focused environment.

## Work History
Customer Service Representative, 06/2020 to Current
Macy's – Arlington,  GA
Offer buying advice to customers to ensure product satisfaction.
Increase sales by 30% using upselling and cross-selling tactics.
Solve common customer concerns and escalate the situation to management if needed.


Customer Service Representative, 11/2018 to 05/2020
    Levis Strauss & Co – Arlington, GA
    Located products in the store and placed orders of out-of-stock items.
    Responded to customer requests for products, services and brand information.
    Educated customers on promotions, increasing sales by 15%.

Cashier, 08/2017 to 10/2018
Shake Shack – Abbeville, GA
Balanced the till upon completion of each shift, solving any discrepancies.
Answered questions about store policies and addressed customer concerns.
Used POS system to enter orders and process payments.

Skills

Technical           Communications      
Microsoft Suite     Complaint resolution
Programing (Python) Sales expertise     

Education

Degree              School               Year
Associates Degree   PCCC                 2014
Bachelors Degree    NJIT                 2017
