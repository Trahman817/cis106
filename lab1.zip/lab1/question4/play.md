In ruby to display text on the screen we use the 'puts' method
In bash to do the same thing we use<br>'echo'<br>
and if I want to create a small program to print hello world i can do it like this:

In Ruby:

'''ruby
puts "hello world"
puts "this is my first program"

In bash:

'''
echo "hello world"
echo "this is my first program"
'''
