


# Food list for today
1. Pizza
2. ice cream
3. pepsi
4. candy
5. water
6. chips
7. soda

## to do list
* clean house
* sweep
* mop
* dish
* garbage
  
  + laptop
  - clean room